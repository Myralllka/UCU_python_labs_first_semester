#include <stdio.h>

int main() {
    int n, m;

    scanf("%d %d", &n, &m);

    int counter = 1;
    char *chr = "";

    int column, row = 0, 0;

    for (int i = 0; i < n; i++) {
        for (int j = 0; j<m; j++) {

        }
    }
    return 0;
}